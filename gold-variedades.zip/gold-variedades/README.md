# GOLD VARIEDADES

Vitrine de produtos afiliados (sem carrinho nem pagamento). Flask + SQLite + HTML/CSS/JS.

## Rodar no VS Code
1. Instale o Python 3.9+ (python.org). No instalador do Windows, marque "Add Python to PATH".
2. No VS Code: Arquivo > Abrir Pasta > escolha `gold-variedades`.
3. Abra o terminal (Ctrl+`) e crie o ambiente virtual:
   - Windows: `python -m venv venv` e depois `venv\Scripts\activate`
   - Mac/Linux: `python3 -m venv venv` e depois `source venv/bin/activate`
4. Instale as dependências: `pip install -r requirements.txt`
5. Inicie: `python app.py` (Mac/Linux: `python3 app.py`)
6. Abra http://127.0.0.1:5000 no navegador. Para parar: Ctrl+C.

O banco `database/gold.db` é criado sozinho na primeira execução, já com 8 produtos de exemplo.

## Painel administrativo
Acesse http://127.0.0.1:5000/admin (não há link público para ele).
Login inicial: usuário `admin`, senha `gold123`. **Troque antes de publicar**, definindo variáveis de ambiente:
- Windows (PowerShell): `$env:ADMIN_USER="seu_usuario"; $env:ADMIN_PASSWORD="sua_senha"; $env:SECRET_KEY="texto-longo-aleatorio"`
- Mac/Linux: `export ADMIN_USER=seu_usuario ADMIN_PASSWORD=sua_senha SECRET_KEY=texto-longo-aleatorio`

## Substituir os exemplos por produtos reais
No painel, clique em "Editar" em um produto de exemplo, troque os dados, cole o link de afiliado e envie a imagem.
Ao salvar, a marca "Exemplo" some. Também dá para excluir os exemplos.

## Estrutura
app.py (rotas e banco) | templates/ (páginas) | static/css, static/js | static/uploads (imagens enviadas) | database/ (SQLite)

## Publicar online
Use um serviço com Python (ex.: PythonAnywhere, Render) e rode com gunicorn, sem `debug=True`.

## Mostrar no celular (mesma rede Wi-Fi)
1. No Windows (PowerShell, com o ambiente virtual ativo): `$env:HOST="0.0.0.0"; python app.py`
2. Em outro terminal, rode `ipconfig` e anote o "Endereço IPv4" (ex.: 192.168.0.15).
3. No celular, conectado ao mesmo Wi-Fi, abra `http://SEU_IPV4:5000`.
4. Se o Windows perguntar sobre o Firewall, permita em "Redes privadas".
Nesse modo o site não reinicia sozinho: pare (Ctrl+C) e rode de novo após mudar arquivos.
Troque a senha do painel antes de mostrar a outras pessoas.

## Celular com e-mail (atalho)
No terminal, dentro da pasta do projeto: `.\iniciar-celular.ps1`. O script descobre o IP, pede a senha de app do Gmail
(sem mostrar na tela) e liga o site. No terminal aparece "E-mail OK" quando o envio estiver funcionando.
