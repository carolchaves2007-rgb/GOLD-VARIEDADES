import os, re, secrets, sqlite3, unicodedata, uuid, json, math, smtplib, hashlib, hmac, urllib.request, urllib.parse
from datetime import datetime, timedelta
from email.message import EmailMessage
from functools import wraps
from flask import (Flask, g, render_template, request, redirect, url_for,
                   session, flash, abort)
from werkzeug.security import check_password_hash, generate_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "database", "gold.db")
UPLOADS = os.path.join(BASE, "static", "uploads")
EXT = {"png", "jpg", "jpeg", "webp", "gif"}
PAGAMENTOS = {"pix": "Pix", "debito": "Cartão de débito", "credito": "Cartão de crédito", "entrega": "Pagar na entrega"}
MAX_PARCELAS, PARCELA_MINIMA = 12, 20.0  # até 12x sem juros, parcela mínima de R$ 20,00
PIX_CHAVE = os.environ.get("PIX_CHAVE")
PERFIS = {"influenciador": "Influenciador(a)", "marca": "Marca", "loja": "Vendedor(a) / loja"}

app = Flask(__name__)
app.config.update(SECRET_KEY=os.environ.get("SECRET_KEY", "troque-esta-chave"),
                  MAX_CONTENT_LENGTH=4 * 1024 * 1024)
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_HASH = generate_password_hash(os.environ.get("ADMIN_PASSWORD", "gold123"))

# ---------- banco de dados ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.close()

def slugify(t):
    t = unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", t.lower()).strip("-")

DEMO = [
    ("Fone Bluetooth sem fio", "Tecnologia", 299.90, 189.90, 1, 1),
    ("Smartwatch com monitor de atividades", "Tecnologia", 499.00, 349.00, 1, 1),
    ("Luminária de mesa dourada", "Casa e decoração", 159.90, 119.90, 1, 1),
    ("Conjunto de vasos decorativos", "Casa e decoração", 129.00, None, 0, 0),
    ("Bolsa tote de couro sintético", "Moda e acessórios", 219.90, 159.90, 1, 1),
    ("Óculos de sol clássico", "Moda e acessórios", 139.00, None, 0, 0),
    ("Kit de skincare facial", "Beleza", 189.90, 129.90, 1, 1),
    ("Perfume floral 100 ml", "Beleza", 249.00, None, 0, 0),
]

def init_db():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    os.makedirs(UPLOADS, exist_ok=True)
    c = sqlite3.connect(DB)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS categorias(
      id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL UNIQUE, slug TEXT NOT NULL UNIQUE);
    CREATE TABLE IF NOT EXISTS clientes(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
      whatsapp TEXT, senha_hash TEXT NOT NULL, criado_em TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS recuperacoes(token_hash TEXT PRIMARY KEY, cliente_id INTEGER, exp TEXT);
    CREATE TABLE IF NOT EXISTS enderecos(id INTEGER PRIMARY KEY AUTOINCREMENT, cliente_id INTEGER, apelido TEXT, cep TEXT, rua TEXT,
      numero TEXT, bairro TEXT, cidade TEXT, uf TEXT, padrao INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS favoritos(cliente_id INTEGER, produto_id INTEGER, PRIMARY KEY(cliente_id, produto_id));
    CREATE TABLE IF NOT EXISTS avaliacoes(id INTEGER PRIMARY KEY AUTOINCREMENT, produto_id INTEGER, cliente_id INTEGER, nota INTEGER,
      comentario TEXT, foto TEXT, criado_em TEXT, UNIQUE(produto_id, cliente_id));
    CREATE TABLE IF NOT EXISTS pendentes(email TEXT PRIMARY KEY, dados TEXT, codigo_hash TEXT, exp TEXT, tent INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS pedidos(id INTEGER PRIMARY KEY AUTOINCREMENT, cliente_id INTEGER, subtotal REAL, frete REAL, dias INTEGER,
      km INTEGER, total REAL, endereco TEXT, status TEXT DEFAULT 'recebido', criado_em TEXT);
    CREATE TABLE IF NOT EXISTS itens(id INTEGER PRIMARY KEY AUTOINCREMENT, pedido_id INTEGER, produto_id INTEGER, nome TEXT,
      preco REAL, qtd INTEGER, vendedor_id INTEGER);
    CREATE TABLE IF NOT EXISTS contatos(id INTEGER PRIMARY KEY AUTOINCREMENT, vendedor_id INTEGER, nome TEXT, email TEXT, mensagem TEXT, criado_em TEXT);
    CREATE TABLE IF NOT EXISTS reclamacoes(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, vendedor_id INTEGER, assunto TEXT, texto TEXT, criado_em TEXT);
    CREATE TABLE IF NOT EXISTS vendedores(
      id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
      senha_hash TEXT NOT NULL, criado_em TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS produtos(
      id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, descricao TEXT NOT NULL,
      imagem TEXT, categoria_id INTEGER NOT NULL REFERENCES categorias(id),
      preco_original REAL NOT NULL, preco_promocional REAL, desconto INTEGER DEFAULT 0,
      link_afiliado TEXT, destaque INTEGER DEFAULT 0, oferta INTEGER DEFAULT 0,
      demo INTEGER DEFAULT 0, criado_em TEXT DEFAULT CURRENT_TIMESTAMP);""")
    cols = [r[1] for r in c.execute("PRAGMA table_info(produtos)")]
    if "vendedor_id" not in cols:
        c.execute("ALTER TABLE produtos ADD COLUMN vendedor_id INTEGER")
    if "status" not in cols:
        c.execute("ALTER TABLE produtos ADD COLUMN status TEXT DEFAULT 'aprovado'")
    if "estoque" not in cols:
        c.execute("ALTER TABLE produtos ADD COLUMN estoque INTEGER DEFAULT 20")
    if "origem" not in cols:
        c.execute("ALTER TABLE produtos ADD COLUMN origem TEXT DEFAULT 'afiliado'")
    if "perfil" not in [r[1] for r in c.execute("PRAGMA table_info(vendedores)")]:
        c.execute("ALTER TABLE vendedores ADD COLUMN perfil TEXT DEFAULT 'influenciador'")
    cp = [r[1] for r in c.execute("PRAGMA table_info(pedidos)")]
    if "pagamento" not in cp:
        c.execute("ALTER TABLE pedidos ADD COLUMN pagamento TEXT")
    if "pago" not in cp:
        c.execute("ALTER TABLE pedidos ADD COLUMN pago INTEGER DEFAULT 0")
    for col, tipo in (("parcelas", "INTEGER DEFAULT 1"), ("cartao_final", "TEXT"), ("bandeira", "TEXT")):
        if col not in cp:
            c.execute(f"ALTER TABLE pedidos ADD COLUMN {col} {tipo}")
    if not c.execute("SELECT 1 FROM categorias").fetchone():
        for n in ("Tecnologia", "Casa e decoração", "Moda e acessórios", "Beleza"):
            c.execute("INSERT INTO categorias(nome,slug) VALUES(?,?)", (n, slugify(n)))
        for nome, cat, po, pp, dest, of in DEMO:
            cid = c.execute("SELECT id FROM categorias WHERE nome=?", (cat,)).fetchone()[0]
            c.execute("""INSERT INTO produtos(nome,descricao,categoria_id,preco_original,
              preco_promocional,desconto,destaque,oferta,demo) VALUES(?,?,?,?,?,?,?,?,1)""",
              (f"{nome} (exemplo)", "Produto demonstrativo. Edite no painel e cole o link de afiliado real.",
               cid, po, pp, calc_desc(po, pp), dest, of))
    c.commit(); c.close()

def calc_desc(po, pp):
    return round((1 - pp / po) * 100) if pp and po and pp < po else 0

def parse_preco(s):
    s = (s or "").replace("R$", "").strip().replace(" ", "")
    if not s:
        return None
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    try:
        v = float(s)
    except ValueError:
        return None
    return v if v > 0 else None

@app.template_filter("brl")
def brl(v):
    return "R$ " + f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

@app.template_filter("img")
def img(p):
    if not p:
        return ""
    return p if p.startswith("http") else url_for("static", filename=p)

@app.template_filter("perfil")
def perfil_nome(k):
    return PERFIS.get(k, "")

# ---------- mensagens (e-mail / WhatsApp) ----------
SMTP_HOST, SMTP_PORT = os.environ.get("SMTP_HOST"), int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER, SMTP_PASS = os.environ.get("SMTP_USER"), os.environ.get("SMTP_PASS")
LOJA_EMAIL = os.environ.get("LOJA_EMAIL", "contato@goldvariedades.local")
MODO_TESTE = not SMTP_HOST  # sem SMTP configurado, as mensagens aparecem no terminal

def testar_smtp():
    """Na inicialização, confere se o login no e-mail funciona e avisa no terminal."""
    if MODO_TESTE: return
    if not SMTP_PASS or SMTP_PASS.upper().startswith("SENHA"):
        print("\nATENÇÃO: a senha de app do e-mail não foi preenchida. Os e-mails NÃO serão enviados.\n"); return
    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as s:
            s.starttls(); s.login(SMTP_USER, SMTP_PASS)
        print(f"\nE-mail OK: o login em {SMTP_USER} funcionou. Os e-mails serão enviados.\n")
    except Exception as e:
        print(f"\nATENÇÃO: não consegui entrar no e-mail ({e}). Confira o e-mail e a senha de app (16 letras, sem espaços).\n")

def enviar(email, whatsapp, assunto, texto):
    """Retorna True se a mensagem foi entregue (ou mostrada no terminal em modo de teste)."""
    ok = True
    if email:
        if MODO_TESTE:
            print(f"\n[E-MAIL para {email}] {assunto}\n{texto}\n")
        else:
            try:
                m = EmailMessage(); m["Subject"], m["From"], m["To"] = assunto, SMTP_USER, email; m.set_content(texto)
                with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as s:
                    s.starttls(); s.login(SMTP_USER, SMTP_PASS); s.send_message(m)
            except Exception as e:
                print("Falha no e-mail:", e); ok = False
    if whatsapp:
        if MODO_TESTE:
            print(f"\n[WHATSAPP para {whatsapp}] {texto}\n")
        else:
            ok = False  # envio real exige um provedor de WhatsApp (Twilio, Meta Cloud API...)
    return ok

# ---------- frete por distância ----------
ORIGEM_CEP = os.environ.get("LOJA_CEP", "01001-000")

def geocodificar(cep):
    try:
        u = "https://nominatim.openstreetmap.org/search?" + urllib.parse.urlencode({"postalcode": cep, "country": "Brazil", "format": "json", "limit": 1})
        d = json.load(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "gold-variedades/1.0"}), timeout=6))
        return (float(d[0]["lat"]), float(d[0]["lon"])) if d else None
    except Exception:
        return None

def calcular_frete(cep):
    a, b = geocodificar(ORIGEM_CEP), geocodificar(cep)
    if not a or not b:
        return dict(km=None, valor=19.90, dias=7)
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    h = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(math.radians(b[1] - a[1]) / 2) ** 2
    km = round(6371 * 2 * math.asin(math.sqrt(h)))
    return dict(km=km, valor=round(min(79.90, 9.90 + 0.12 * km), 2), dias=2 + km // 400)

# ---------- CSRF ----------
@app.before_request
def csrf():
    if request.method == "POST":
        if not session.get("csrf") or request.form.get("csrf") != session["csrf"]:
            abort(400, "Sessão expirada. Volte e tente novamente.")

@app.context_processor
def ctx():
    session.setdefault("csrf", secrets.token_hex(16))
    cli = db().execute("SELECT id, nome FROM clientes WHERE id=?", (session.get("cliente"),)).fetchone() if session.get("cliente") else None
    if session.get("cliente") and not cli: session.pop("cliente", None)
    favs = {r[0] for r in db().execute("SELECT produto_id FROM favoritos WHERE cliente_id=?", (cli["id"],))} if cli else set()
    return dict(conta=cli, favs=favs, csrf=session["csrf"], categorias=db().execute(
        "SELECT * FROM categorias ORDER BY nome").fetchall(), admin=session.get("admin"), vendedor=session.get("vendedor"), cliente=session.get("cliente"), n_carrinho=sum(session.get("carrinho", {}).values()))

# ---------- consulta de produtos ----------
def listar(q="", cat="", ordem="", promo=False, destaque=False, limit=None, todos=False, vendedor=None, origem=None):
    sql = ("SELECT p.*, c.nome cat_nome, c.slug cat_slug, v.nome vendedor_nome, (SELECT AVG(nota) FROM avaliacoes a WHERE a.produto_id=p.id) media, (SELECT COUNT(*) FROM avaliacoes a WHERE a.produto_id=p.id) n_aval, (SELECT COALESCE(SUM(i.qtd),0) FROM itens i WHERE i.produto_id=p.id) vendidos FROM produtos p "
           "JOIN categorias c ON c.id=p.categoria_id LEFT JOIN vendedores v ON v.id=p.vendedor_id WHERE 1=1")
    a = []
    if not todos:
        sql += " AND p.status='aprovado'"
    if vendedor:
        sql += " AND p.vendedor_id=?"; a.append(vendedor)
    if origem:
        sql += " AND p.origem=?"; a.append(origem)
    if q:
        sql += " AND (p.nome LIKE ? OR p.descricao LIKE ?)"; a += [f"%{q}%"] * 2
    if cat and cat not in ("todos", "ofertas"):
        sql += " AND c.slug=?"; a.append(cat)
    if promo or cat == "ofertas":
        sql += " AND (p.oferta=1 OR p.preco_promocional IS NOT NULL)"
    if destaque:
        sql += " AND p.destaque=1"
    preco = "COALESCE(p.preco_promocional,p.preco_original)"
    sql += {"menor": f" ORDER BY {preco} ASC", "maior": f" ORDER BY {preco} DESC",
            "novidades": " ORDER BY p.id DESC", "vendidos": " ORDER BY vendidos DESC, p.id DESC", "avaliados": " ORDER BY (n_aval=0), media DESC, n_aval DESC"}.get(ordem, " ORDER BY p.destaque DESC, p.id DESC")
    if limit:
        sql += f" LIMIT {int(limit)}"
    return db().execute(sql, a).fetchall()

# ---------- páginas públicas ----------
@app.route("/")
def home():
    cats = db().execute("""SELECT c.*, COUNT(p.id) total FROM categorias c
        LEFT JOIN produtos p ON p.categoria_id=c.id AND p.status='aprovado' GROUP BY c.id ORDER BY c.nome""").fetchall()
    ofs = [p for p in listar(promo=True) if (p["estoque"] or 0) > 0]
    agora = datetime.now()  # a Oferta Gold do dia troca sozinha à meia-noite
    gold, segundos = (ofs[agora.toordinal() % len(ofs)] if ofs else None), int((agora.replace(hour=23, minute=59, second=59) - agora).total_seconds()) + 1
    return render_template("index.html", cats=cats, gold=gold, segundos=segundos,
        mais_vendidos=[p for p in listar(ordem="vendidos", limit=8) if p["vendidos"] > 0][:4],
        avaliados=[p for p in listar(ordem="avaliados", limit=8) if p["n_aval"] > 0][:4],
        destaques=listar(destaque=True, limit=4), ofertas=listar(promo=True, limit=4),
        novidades=listar(ordem="novidades", limit=4))

@app.route("/produtos")
@app.route("/categoria/<slug>")
def catalogo(slug=""):
    cat = slug or request.args.get("cat", "")
    q, ordem, promo = request.args.get("q", "").strip(), request.args.get("ordem", ""), bool(request.args.get("promo"))
    titulo = {"": "Todos os produtos", "todos": "Todos os produtos", "ofertas": "Ofertas"}.get(cat)
    if titulo is None:
        c = db().execute("SELECT nome FROM categorias WHERE slug=?", (cat,)).fetchone()
        if not c: abort(404)
        titulo = c["nome"]
    return render_template("catalogo.html", produtos=listar(q, cat, ordem, promo),
                           titulo=titulo, cat=cat, q=q, ordem=ordem, promo=promo)

@app.route("/produto/<int:pid>")
def produto(pid):
    p = db().execute("""SELECT p.*, c.nome cat_nome, c.slug cat_slug, v.nome vendedor_nome FROM produtos p
        JOIN categorias c ON c.id=p.categoria_id LEFT JOIN vendedores v ON v.id=p.vendedor_id WHERE p.id=?""", (pid,)).fetchone()
    if not p or (p["status"] != "aprovado" and not session.get("admin") and p["vendedor_id"] != session.get("vendedor")): abort(404)
    avals = db().execute("""SELECT a.*, c.nome cliente, EXISTS(SELECT 1 FROM itens i JOIN pedidos pe ON pe.id=i.pedido_id
        WHERE i.produto_id=a.produto_id AND pe.cliente_id=a.cliente_id) verificada FROM avaliacoes a JOIN clientes c ON c.id=a.cliente_id
        WHERE a.produto_id=? ORDER BY a.id DESC""", (pid,)).fetchall()
    st = db().execute("SELECT AVG(nota), COUNT(*) FROM avaliacoes WHERE produto_id=?", (pid,)).fetchone()
    minha = db().execute("SELECT * FROM avaliacoes WHERE produto_id=? AND cliente_id=?", (pid, session["cliente"])).fetchone() if session.get("cliente") else None
    return render_template("produto.html", p=p, avals=avals, total=st[1], media=(f"{st[0]:.1f}".replace(".", ",") if st[1] else None), minha=minha, rel=[x for x in listar(cat=p["cat_slug"], limit=5) if x["id"] != pid][:4])

@app.errorhandler(404)
@app.errorhandler(400)
def erro(e):
    return render_template("erro.html", e=e), e.code

# ---------- administração ----------
def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("admin"):
            return redirect(url_for("login", next=request.path))
        return f(*a, **k)
    return w

@app.route("/admin/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if request.form.get("usuario") == ADMIN_USER and check_password_hash(ADMIN_HASH, request.form.get("senha", "")):
            session["admin"] = True
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/admin") else url_for("painel"))
        flash("Usuário ou senha incorretos.", "erro")
    return render_template("admin/login.html")

@app.route("/admin/logout", methods=["POST"])
def logout():
    session.pop("admin", None)
    flash("Você saiu do painel.", "ok")
    return redirect(url_for("home"))

@app.route("/admin")
@login_required
def painel():
    return render_template("admin/painel.html", produtos=listar(ordem="novidades", todos=True))

def salvar_imagem(f_atual):
    arq, url = request.files.get("arquivo"), request.form.get("imagem_url", "").strip()
    if arq and arq.filename:
        ext = arq.filename.rsplit(".", 1)[-1].lower()
        if ext not in EXT:
            return f_atual, "Imagem inválida: use PNG, JPG, WEBP ou GIF."
        nome = f"uploads/{uuid.uuid4().hex}.{ext}"
        arq.save(os.path.join(BASE, "static", nome))
        return nome, None
    if url:
        return (url, None) if re.match(r"^https?://", url) else (f_atual, "O endereço da imagem deve começar com http:// ou https://.")
    return f_atual, None

@app.route("/admin/produto/novo", methods=["GET", "POST"])
@app.route("/admin/produto/<int:pid>/editar", methods=["GET", "POST"])
@login_required
def form_produto(pid=None):
    return processar_form(pid)

def processar_form(pid, vid=None):
    atual = db().execute("SELECT * FROM produtos WHERE id=?", (pid,)).fetchone() if pid else None
    if pid and (not atual or (vid and atual["vendedor_id"] != vid)): abort(404)
    o = request.values.get("origem")
    origem = atual["origem"] if atual else (o if o in ("proprio", "afiliado") else "afiliado")
    if request.method == "POST":
        f, erros = request.form, []
        nome, desc = f.get("nome", "").strip(), f.get("descricao", "").strip()
        po, pp = parse_preco(f.get("preco_original")), parse_preco(f.get("preco_promocional"))
        link, cid = f.get("link_afiliado", "").strip(), f.get("categoria_id", "")
        if len(nome) < 3: erros.append("Informe o nome (mínimo 3 letras).")
        try: estoque = int(f.get("estoque", ""))
        except ValueError: estoque = -1
        if not 0 <= estoque <= 100000: erros.append("Informe o estoque (número de unidades, 0 ou mais).")
        if len(desc) < 10: erros.append("A descrição precisa de pelo menos 10 caracteres.")
        if not po: erros.append("Informe um preço original válido.")
        if f.get("preco_promocional", "").strip() and not pp: erros.append("Preço promocional inválido.")
        if po and pp and pp >= po: erros.append("O preço promocional deve ser menor que o original.")
        if not re.match(r"^https?://\S+$", link): erros.append("Cole o link de afiliado completo (começa com http:// ou https://).")
        if not db().execute("SELECT 1 FROM categorias WHERE id=?", (cid,)).fetchone(): erros.append("Escolha uma categoria.")
        imagem, e = salvar_imagem(atual["imagem"] if atual else None)
        if e: erros.append(e)
        if erros:
            for m in erros: flash(m, "erro")
            return render_template("admin/produto_form.html", p=f, atual=atual, parceiro=bool(vid), origem=origem), 400
        dados = (nome, desc, imagem, cid, po, pp, calc_desc(po, pp), link,
                 0 if vid else int(bool(f.get("destaque"))), 0 if vid else int(bool(f.get("oferta"))))
        if atual:
            db().execute("""UPDATE produtos SET nome=?,descricao=?,imagem=?,categoria_id=?,preco_original=?,
                preco_promocional=?,desconto=?,link_afiliado=?,destaque=?,oferta=?,demo=0 WHERE id=?""", dados + (pid,))
        else:
            pid = db().execute("""INSERT INTO produtos(nome,descricao,imagem,categoria_id,preco_original,
                preco_promocional,desconto,link_afiliado,destaque,oferta) VALUES(?,?,?,?,?,?,?,?,?,?)""", dados).lastrowid
        db().execute("UPDATE produtos SET estoque=? WHERE id=?", (estoque, pid))
        if vid:
            db().execute("UPDATE produtos SET vendedor_id=?, status='pendente'" + ("" if atual else f", origem='{origem}'") + " WHERE id=?", (vid, pid))
        db().commit()
        flash("Produto enviado! Ele aparece na loja depois da aprovação." if vid else "Produto salvo com sucesso!", "ok")
        return redirect(url_for("meus_produtos" if vid else "painel"))
    return render_template("admin/produto_form.html", p=atual or {}, atual=atual, parceiro=bool(vid), origem=origem)

@app.route("/admin/produto/<int:pid>/excluir", methods=["POST"])
@login_required
def excluir(pid):
    db().execute("DELETE FROM produtos WHERE id=?", (pid,)); db().commit()
    flash("Produto excluído.", "ok")
    return redirect(url_for("painel"))

@app.route("/admin/produto/<int:pid>/alternar/<campo>", methods=["POST"])
@login_required
def alternar(pid, campo):
    if campo not in ("oferta", "destaque"): abort(400)
    db().execute(f"UPDATE produtos SET {campo}=1-{campo} WHERE id=?", (pid,)); db().commit()
    flash("Produto atualizado.", "ok")
    return redirect(url_for("painel"))

@app.route("/admin/categorias", methods=["GET", "POST"])
@login_required
def gerir_categorias():
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        if len(nome) < 3 or not slugify(nome):
            flash("Informe um nome de categoria com pelo menos 3 letras.", "erro")
        elif db().execute("SELECT 1 FROM categorias WHERE slug IN (?, 'todos','ofertas')", (slugify(nome),)).fetchone() or slugify(nome) in ("todos", "ofertas"):
            flash("Já existe uma categoria com esse nome.", "erro")
        else:
            db().execute("INSERT INTO categorias(nome,slug) VALUES(?,?)", (nome, slugify(nome))); db().commit()
            flash("Categoria criada!", "ok")
        return redirect(url_for("gerir_categorias"))
    cats = db().execute("""SELECT c.*, COUNT(p.id) total FROM categorias c
        LEFT JOIN produtos p ON p.categoria_id=c.id GROUP BY c.id ORDER BY c.nome""").fetchall()
    return render_template("admin/categorias.html", cats=cats)

@app.route("/admin/categorias/<int:cid>/excluir", methods=["POST"])
@login_required
def excluir_categoria(cid):
    if db().execute("SELECT 1 FROM produtos WHERE categoria_id=?", (cid,)).fetchone():
        flash("Não é possível excluir: há produtos nesta categoria. Mova ou exclua os produtos primeiro.", "erro")
    else:
        db().execute("DELETE FROM categorias WHERE id=?", (cid,)); db().commit()
        flash("Categoria excluída.", "ok")
    return redirect(url_for("gerir_categorias"))

@app.route("/admin/produto/<int:pid>/aprovar", methods=["POST"])
@login_required
def aprovar(pid):
    db().execute("UPDATE produtos SET status='aprovado' WHERE id=?", (pid,)); db().commit()
    flash("Produto aprovado e publicado na loja.", "ok")
    return redirect(url_for("painel"))

# ---------- área do afiliado ----------
def parceiro_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("vendedor"):
            return redirect(url_for("login_parceiro"))
        return f(*a, **k)
    return w

@app.route("/seja-afiliado", methods=["GET", "POST"])
def seja_afiliado():
    f = request.form
    if request.method == "POST":
        nome, email, senha = f.get("nome", "").strip(), f.get("email", "").strip().lower(), f.get("senha", "")
        perfil = f.get("perfil") if f.get("perfil") in PERFIS else "influenciador"
        erros = []
        if len(nome) < 3: erros.append("Informe seu nome (mínimo 3 letras).")
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email): erros.append("Informe um e-mail válido.")
        if len(senha) < 6: erros.append("A senha precisa de pelo menos 6 caracteres.")
        if senha != f.get("senha2"): erros.append("As senhas não são iguais.")
        if not erros and db().execute("SELECT 1 FROM vendedores WHERE email=?", (email,)).fetchone():
            erros.append("Este e-mail já tem cadastro. Use a opção Entrar.")
        if erros:
            for m in erros: flash(m, "erro")
            return render_template("afiliado.html", f=f), 400
        session["vendedor"] = db().execute("INSERT INTO vendedores(nome,email,senha_hash,perfil) VALUES(?,?,?,?)",
            (nome, email, generate_password_hash(senha), perfil)).lastrowid
        db().commit()
        flash("Cadastro concluído! Agora envie seu primeiro produto.", "ok")
        return redirect(url_for("meus_produtos"))
    return render_template("afiliado.html", f={})

@app.route("/parceiro/login", methods=["GET", "POST"])
def login_parceiro():
    if request.method == "POST":
        v = db().execute("SELECT * FROM vendedores WHERE email=?", (request.form.get("email", "").strip().lower(),)).fetchone()
        if v and check_password_hash(v["senha_hash"], request.form.get("senha", "")):
            session["vendedor"] = v["id"]
            enviar(v["email"], None, "Bem-vindo(a) de volta!", f"Olá, {v['nome']}! Você entrou na sua conta da GOLD VARIEDADES.")
            return redirect(url_for("meus_produtos"))
        flash("E-mail ou senha incorretos.", "erro")
    return render_template("parceiro/login.html")

@app.route("/parceiro/logout", methods=["POST"])
def logout_parceiro():
    session.pop("vendedor", None)
    flash("Você saiu da sua conta.", "ok")
    return redirect(url_for("home"))

@app.route("/parceiro")
@parceiro_required
def meus_produtos():
    v = db().execute("SELECT * FROM vendedores WHERE id=?", (session["vendedor"],)).fetchone()
    if not v:
        session.pop("vendedor", None)
        return redirect(url_for("login_parceiro"))
    return render_template("parceiro/painel.html", v=v, produtos=listar(ordem="novidades", todos=True, vendedor=v["id"]))

@app.route("/parceiro/produto/novo", methods=["GET", "POST"])
@app.route("/parceiro/produto/<int:pid>/editar", methods=["GET", "POST"])
@parceiro_required
def form_parceiro(pid=None):
    return processar_form(pid, session["vendedor"])

@app.route("/parceiro/produto/<int:pid>/excluir", methods=["POST"])
@parceiro_required
def excluir_parceiro(pid):
    db().execute("DELETE FROM produtos WHERE id=? AND vendedor_id=?", (pid, session["vendedor"])); db().commit()
    flash("Produto excluído.", "ok")
    return redirect(url_for("meus_produtos"))

def pagina_vendedor(vid, origem):
    v = db().execute("SELECT id, nome, perfil FROM vendedores WHERE id=?", (vid,)).fetchone()
    if not v: abort(404)
    dono = session.get("vendedor") == vid
    pend = db().execute("SELECT COUNT(*) FROM produtos WHERE vendedor_id=? AND origem=? AND status='pendente'", (vid, origem)).fetchone()[0] if dono else 0
    return render_template("loja.html", v=v, dono=dono, pend=pend, modo="loja" if origem == "proprio" else "afiliado",
                           produtos=listar(ordem="novidades", vendedor=vid, origem=origem))

@app.route("/loja/<int:vid>")
def loja(vid):
    return pagina_vendedor(vid, "proprio")

@app.route("/afiliado/<int:vid>")
def vitrine(vid):
    return pagina_vendedor(vid, "afiliado")

@app.route("/minha-loja")
def minha_loja():
    if not session.get("vendedor"):
        return render_template("afiliado.html", f={"modo": "loja"})
    return redirect(url_for("loja", vid=session["vendedor"]))

@app.route("/minha-vitrine")
def minha_vitrine():
    if not session.get("vendedor"):
        return redirect(url_for("seja_afiliado"))
    return redirect(url_for("vitrine", vid=session["vendedor"]))

# ---------- carrinho ----------
def itens_carrinho():
    cart = session.get("carrinho", {})
    if not cart: return [], 0
    ids = [int(k) for k in cart]
    rows = db().execute("SELECT p.*, v.nome vendedor_nome FROM produtos p LEFT JOIN vendedores v ON v.id=p.vendedor_id "
                        f"WHERE p.status='aprovado' AND p.id IN ({','.join('?' * len(ids))})", ids).fetchall()
    itens = [{**dict(r), "qtd": cart[str(r["id"])], "preco": r["preco_promocional"] or r["preco_original"]} for r in rows]
    return itens, round(sum(i["preco"] * i["qtd"] for i in itens), 2)

@app.route("/carrinho")
def carrinho():
    itens, sub_ = itens_carrinho()
    fr = session.get("frete")
    return render_template("carrinho.html", itens=itens, subtotal=sub_, end=session.get("end", {}), fr=fr, salvos=enderecos_salvos(),
                           total=round(sub_ + fr["valor"], 2) if fr else sub_,
                           max_parc=max(1, min(MAX_PARCELAS, int((round(sub_ + fr["valor"], 2) if fr else sub_) // PARCELA_MINIMA))))

@app.route("/carrinho/adicionar/<int:pid>", methods=["POST"])
def carrinho_add(pid):
    p_ = db().execute("SELECT estoque FROM produtos WHERE id=? AND status='aprovado'", (pid,)).fetchone()
    if not p_: abort(404)
    cart = session.get("carrinho", {})
    novo = cart.get(str(pid), 0) + 1
    if novo > (p_["estoque"] or 0):
        flash("Produto esgotado." if not p_["estoque"] else f"Só temos {p_['estoque']} unidade(s) em estoque.", "erro")
        ref = request.referrer or ""
        return redirect(ref if ref.startswith(request.host_url) else url_for("carrinho"))
    cart[str(pid)] = min(novo, 20)
    session["carrinho"] = cart; session.pop("frete", None)
    flash("Produto adicionado ao carrinho.", "ok")
    ref = request.referrer or ""
    return redirect(ref if ref.startswith(request.host_url) else url_for("carrinho"))

@app.route("/carrinho/atualizar", methods=["POST"])
def carrinho_atualizar():
    cart = {}
    est = {str(r["id"]): r["estoque"] or 0 for r in db().execute("SELECT id, estoque FROM produtos")}
    for k in session.get("carrinho", {}):
        try: q = int(request.form.get(f"qtd_{k}", 0))
        except ValueError: q = 0
        q = min(q, est.get(k, 0))
        if q > 0 and request.form.get("remover") != k: cart[k] = min(q, 20)
    session["carrinho"] = cart; session.pop("frete", None)
    flash("Carrinho atualizado.", "ok")
    return redirect(url_for("carrinho"))

@app.route("/carrinho/frete", methods=["POST"])
def carrinho_frete():
    f = request.form
    end = {k: f.get(k, "").strip() for k in ("cep", "rua", "numero", "bairro", "cidade", "uf")}
    erros = []
    if not re.match(r"^\d{5}-?\d{3}$", end["cep"]): erros.append("CEP inválido. Use o formato 00000-000.")
    for k, nome in (("rua", "a rua"), ("numero", "o número"), ("bairro", "o bairro"), ("cidade", "a cidade")):
        if not end[k]: erros.append(f"Informe {nome}.")
    if len(end["uf"]) != 2: erros.append("Informe o estado com 2 letras (ex.: SP).")
    session["end"] = end
    if erros:
        for m in erros: flash(m, "erro")
    else:
        session["frete"] = calcular_frete(end["cep"])
        flash("Frete calculado.", "ok")
    return redirect(url_for("carrinho"))

@app.route("/carrinho/cancelar", methods=["POST"])
def carrinho_cancelar():
    for k in ("carrinho", "frete", "end"): session.pop(k, None)
    flash("Pedido cancelado e carrinho esvaziado.", "ok")
    return redirect(url_for("home"))

@app.route("/pedido/finalizar", methods=["POST"])
def finalizar():
    if not session.get("cliente"):
        flash("Entre na sua conta para finalizar o pedido.", "erro")
        return redirect(url_for("login_cliente"))
    pg = request.form.get("pagamento")
    if pg not in ("pix", "debito", "credito"):
        flash("Escolha a forma de pagamento antes de prosseguir.", "erro")
        return redirect(url_for("carrinho"))
    itens, sub_ = itens_carrinho(); fr, end = session.get("frete"), session.get("end")
    if not itens or not fr or not end:
        flash("Preencha o endereço e calcule o frete antes de prosseguir.", "erro")
        return redirect(url_for("carrinho"))
    total = round(sub_ + fr["valor"], 2)
    parc, final, band = 1, None, None
    if pg in ("debito", "credito"):  # o número e o CVV do cartão NUNCA chegam ao servidor: só bandeira e final
        final, band = re.sub(r"\D", "", request.form.get("cartao_final", "")), request.form.get("bandeira", "")[:20]
        try: parc = int(request.form.get("parcelas", "1"))
        except ValueError: parc = 0
        maxp = max(1, min(MAX_PARCELAS, int(total // PARCELA_MINIMA))) if pg == "credito" else 1
        if len(final) != 4 or not 1 <= parc <= maxp:
            flash("Confira os dados do cartão e o número de parcelas.", "erro")
            return redirect(url_for("carrinho"))
    texto_end = f"{end['rua']}, {end['numero']} - {end['bairro']}, {end['cidade']}/{end['uf'].upper()} - CEP {end['cep']}"
    agora = datetime.now()
    pid = db().execute("INSERT INTO pedidos(cliente_id,subtotal,frete,dias,km,total,endereco,criado_em,pagamento,parcelas,cartao_final,bandeira) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (session["cliente"], sub_, fr["valor"], fr["dias"], fr["km"], round(sub_ + fr["valor"], 2), texto_end, agora.isoformat(), pg, parc, final, band)).lastrowid
    for i in itens:
        db().execute("INSERT INTO itens(pedido_id,produto_id,nome,preco,qtd,vendedor_id) VALUES(?,?,?,?,?,?)", (pid, i["id"], i["nome"], i["preco"], i["qtd"], i["vendedor_id"]))
        if db().execute("UPDATE produtos SET estoque=estoque-? WHERE id=? AND estoque>=?", (i["qtd"], i["id"], i["qtd"])).rowcount == 0:
            db().rollback()
            flash(f"Estoque insuficiente para {i['nome']}. Ajuste o carrinho.", "erro")
            return redirect(url_for("carrinho"))
    db().commit()
    for vid in {i["vendedor_id"] for i in itens}:
        meus = [i for i in itens if i["vendedor_id"] == vid]
        v = db().execute("SELECT email FROM vendedores WHERE id=?", (vid,)).fetchone() if vid else None
        valor = sum(i["preco"] * i["qtd"] for i in meus)
        enviar(v["email"] if v else LOJA_EMAIL, None, f"Nova compra #{pid}",
               f"Compra feita em {agora:%d/%m/%Y às %H:%M}.\nItens: " + "; ".join(f"{i['qtd']}x {i['nome']}" for i in meus) +
               f"\nValor dos seus produtos: {brl(valor)}\nEndereço de entrega: {texto_end}\nPagamento: {PAGAMENTOS[pg]}{(' em ' + str(parc) + 'x') if pg == 'credito' else ''}")
    for k in ("carrinho", "frete", "end"): session.pop(k, None)
    flash(f"Pedido #{pid} realizado com sucesso!", "ok")
    return redirect(url_for("ver_pedido", pid=pid))

# ---------- contas de clientes ----------
def hash_codigo(email, codigo):
    return hashlib.sha256(f"{email}|{codigo}|{app.config['SECRET_KEY']}".encode()).hexdigest()

def mandar_codigo(email, whatsapp, canal):
    codigo = f"{secrets.randbelow(10000):04d}"
    db().execute("UPDATE pendentes SET codigo_hash=?, exp=?, tent=0 WHERE email=?",
                 (hash_codigo(email, codigo), (datetime.now() + timedelta(minutes=10)).isoformat(), email)); db().commit()
    return enviar(email if canal == "email" else None, whatsapp if canal == "whatsapp" else None,
                  "Seu código GOLD VARIEDADES", f"Seu código de confirmação é {codigo}. Ele vale por 10 minutos.")

@app.route("/cadastro", methods=["GET", "POST"])
def cadastro_cliente():
    f = request.form
    if request.method == "POST":
        nome, email, zap = f.get("nome", "").strip(), f.get("email", "").strip().lower(), re.sub(r"\D", "", f.get("whatsapp", ""))
        canal, senha, erros = f.get("canal", "email"), f.get("senha", ""), []
        if len(nome) < 3: erros.append("Informe seu nome (mínimo 3 letras).")
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email): erros.append("Informe um e-mail válido.")
        if zap and not 10 <= len(zap) <= 13: erros.append("WhatsApp inválido. Use DDD + número.")
        if canal == "whatsapp" and not zap: erros.append("Para receber o código no WhatsApp, informe o número.")
        if len(senha) < 6: erros.append("A senha precisa de pelo menos 6 caracteres.")
        if not erros and db().execute("SELECT 1 FROM clientes WHERE email=?", (email,)).fetchone(): erros.append("Este e-mail já tem cadastro. Use Entrar.")
        if not erros:
            db().execute("INSERT OR REPLACE INTO pendentes(email,dados) VALUES(?,?)", (email, json.dumps({"nome": nome, "zap": zap, "senha": generate_password_hash(senha)})))
            if not mandar_codigo(email, zap, canal):
                db().execute("DELETE FROM pendentes WHERE email=?", (email,)); db().commit()
                erros.append("Não foi possível enviar o código. Se escolheu WhatsApp, use o e-mail. Se escolheu e-mail, confira a configuração do envio (o terminal mostra o motivo).")
        if erros:
            for m in erros: flash(m, "erro")
            return render_template("cliente_cadastro.html", f=f), 400
        session["pend_email"] = email
        flash("Código enviado! Digite os 4 dígitos para concluir o cadastro." + (" (Modo de teste: veja o código no terminal do VS Code.)" if MODO_TESTE else ""), "ok")
        return redirect(url_for("codigo_cliente"))
    return render_template("cliente_cadastro.html", f={})

@app.route("/cadastro/codigo", methods=["GET", "POST"])
def codigo_cliente():
    email = session.get("pend_email")
    p = db().execute("SELECT * FROM pendentes WHERE email=?", (email,)).fetchone() if email else None
    if not p: return redirect(url_for("cadastro_cliente"))
    if request.method == "POST":
        acao, dados = request.form.get("acao"), json.loads(p["dados"])
        if acao == "reenviar":
            canal = request.form.get("canal", "email")
            if canal == "whatsapp" and not dados["zap"]: flash("Você não informou um WhatsApp no cadastro.", "erro")
            elif mandar_codigo(email, dados["zap"], canal): flash("Novo código enviado.", "ok")
            else: flash("Não foi possível enviar por esse canal.", "erro")
            return redirect(url_for("codigo_cliente"))
        cod = request.form.get("codigo", "").strip()
        if not p["codigo_hash"] or datetime.fromisoformat(p["exp"]) < datetime.now() or p["tent"] >= 5:
            flash("Código expirado ou com muitas tentativas. Peça um novo código.", "erro")
        elif not hmac.compare_digest(hash_codigo(email, cod), p["codigo_hash"]):
            db().execute("UPDATE pendentes SET tent=tent+1 WHERE email=?", (email,)); db().commit()
            flash("Código incorreto.", "erro")
        else:
            cid = db().execute("INSERT INTO clientes(nome,email,whatsapp,senha_hash) VALUES(?,?,?,?)", (dados["nome"], email, dados["zap"], dados["senha"])).lastrowid
            db().execute("DELETE FROM pendentes WHERE email=?", (email,)); db().commit()
            session.pop("pend_email", None); session["cliente"] = cid
            enviar(email, dados["zap"], "Bem-vindo(a) à GOLD VARIEDADES!", f"Olá, {dados['nome']}! Seu cadastro foi confirmado. Boas compras!")
            flash("Cadastro confirmado! Bem-vindo(a).", "ok")
            return redirect(url_for("minha_conta"))
        return redirect(url_for("codigo_cliente"))
    return render_template("cliente_codigo.html", email=email)

@app.route("/entrar", methods=["GET", "POST"])
def login_cliente():
    if request.method == "POST":
        c = db().execute("SELECT * FROM clientes WHERE email=?", (request.form.get("email", "").strip().lower(),)).fetchone()
        if c and check_password_hash(c["senha_hash"], request.form.get("senha", "")):
            session["cliente"] = c["id"]
            enviar(c["email"], c["whatsapp"], "Bem-vindo(a) de volta!", f"Olá, {c['nome']}! Você entrou na sua conta da GOLD VARIEDADES.")
            return redirect(url_for("carrinho" if session.get("carrinho") else "minha_conta"))
        flash("E-mail ou senha incorretos.", "erro")
    return render_template("cliente_login.html")

@app.route("/sair", methods=["POST"])
def logout_cliente():
    session.pop("cliente", None)
    flash("Você saiu da sua conta.", "ok")
    return redirect(url_for("home"))

# ---------- pedidos e rastreio ----------
ETAPAS = [("recebido", "Pedido recebido"), ("retirado", "Retirado"), ("a_caminho", "A caminho"), ("entregue", "Entregue")]

def pedidos_do(cliente, so=None):
    ps = db().execute("SELECT * FROM pedidos WHERE cliente_id=?" + (" AND id=?" if so else "") + " ORDER BY id DESC", (cliente, so) if so else (cliente,)).fetchall()
    return [{**dict(p), "itens": db().execute("SELECT * FROM itens WHERE pedido_id=?", (p["id"],)).fetchall()} for p in ps]

@app.route("/meus-pedidos")
def meus_pedidos():
    if not session.get("cliente"):
        flash("Entre na sua conta para ver seus pedidos.", "erro")
        return redirect(url_for("login_cliente"))
    return render_template("pedidos.html", pedidos=pedidos_do(session["cliente"]), etapas=ETAPAS, pagamentos=PAGAMENTOS, pix_chave=PIX_CHAVE, titulo="Meus pedidos")

@app.route("/pedido/<int:pid>")
def ver_pedido(pid):
    if not session.get("cliente"): return redirect(url_for("login_cliente"))
    ps = pedidos_do(session["cliente"], pid)
    if not ps: abort(404)
    return render_template("pedidos.html", pedidos=ps, etapas=ETAPAS, pagamentos=PAGAMENTOS, pix_chave=PIX_CHAVE, titulo=f"Rastreio do pedido #{pid}")

@app.route("/admin/pedidos")
@login_required
def admin_pedidos():
    ps = db().execute("SELECT p.*, c.nome cliente FROM pedidos p LEFT JOIN clientes c ON c.id=p.cliente_id ORDER BY p.id DESC").fetchall()
    return render_template("admin/pedidos.html", pedidos=ps, etapas=ETAPAS, pagamentos=PAGAMENTOS)

@app.route("/admin/pedido/<int:pid>/status", methods=["POST"])
@login_required
def admin_status(pid):
    st = request.form.get("status")
    if st not in dict(ETAPAS): abort(400)
    db().execute("UPDATE pedidos SET status=? WHERE id=?", (st, pid)); db().commit()
    flash("Status do pedido atualizado.", "ok")
    return redirect(url_for("admin_pedidos"))

# ---------- Reclame Aqui e contato ----------
@app.route("/reclame-aqui", methods=["GET", "POST"])
def reclame():
    if request.method == "POST":
        f = request.form; nome, ass, txt = f.get("nome", "").strip(), f.get("assunto", "").strip(), f.get("texto", "").strip()
        if len(nome) < 3 or len(ass) < 5 or len(txt) < 20:
            flash("Preencha seu nome, o assunto e descreva o problema (mínimo 20 caracteres).", "erro")
        else:
            db().execute("INSERT INTO reclamacoes(nome,vendedor_id,assunto,texto,criado_em) VALUES(?,?,?,?,?)",
                         (nome, int(f.get("vendedor_id") or 0) or None, ass, txt, datetime.now().isoformat())); db().commit()
            flash("Reclamação registrada. Obrigado por avisar!", "ok")
            return redirect(url_for("reclame"))
    lista = db().execute("SELECT r.*, v.nome vendedor FROM reclamacoes r LEFT JOIN vendedores v ON v.id=r.vendedor_id ORDER BY r.id DESC LIMIT 50").fetchall()
    vend = db().execute("SELECT id, nome FROM vendedores ORDER BY nome").fetchall()
    return render_template("reclame.html", lista=lista, vend=vend, f=request.form)

@app.route("/contato/<int:vid>", methods=["GET", "POST"])
def contato(vid):
    v = db().execute("SELECT id, nome, email FROM vendedores WHERE id=?", (vid,)).fetchone() if vid else None
    if vid and not v: abort(404)
    if request.method == "POST":
        f = request.form; nome, email, msg = f.get("nome", "").strip(), f.get("email", "").strip(), f.get("mensagem", "").strip()
        if len(nome) < 3 or not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email) or len(msg) < 10:
            flash("Informe seu nome, um e-mail válido e a mensagem (mínimo 10 caracteres).", "erro")
        else:
            db().execute("INSERT INTO contatos(vendedor_id,nome,email,mensagem,criado_em) VALUES(?,?,?,?,?)", (vid or None, nome, email, msg, datetime.now().isoformat())); db().commit()
            enviar(v["email"] if v else LOJA_EMAIL, None, f"Mensagem de {nome}", f"{msg}\n\nResponder para: {email}")
            flash("Mensagem enviada!", "ok")
            return redirect(url_for("contato", vid=vid))
    return render_template("contato.html", v=v, f=request.form)

@app.route("/parceiro/mensagens")
@parceiro_required
def mensagens_parceiro():
    ms = db().execute("SELECT * FROM contatos WHERE vendedor_id=? ORDER BY id DESC", (session["vendedor"],)).fetchall()
    return render_template("parceiro/mensagens.html", ms=ms)

# ---------- recuperação de senha ----------
@app.route("/esqueci-senha", methods=["GET", "POST"])
def esqueci_senha():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        c = db().execute("SELECT * FROM clientes WHERE email=?", (email,)).fetchone()
        if c:
            recente = db().execute("SELECT 1 FROM recuperacoes WHERE cliente_id=? AND exp>?",
                                   (c["id"], (datetime.now() + timedelta(minutes=59)).isoformat())).fetchone()
            if not recente:  # no máximo um link por minuto
                token = secrets.token_urlsafe(32)
                db().execute("DELETE FROM recuperacoes WHERE cliente_id=?", (c["id"],))
                db().execute("INSERT INTO recuperacoes(token_hash,cliente_id,exp) VALUES(?,?,?)",
                             (hashlib.sha256(token.encode()).hexdigest(), c["id"], (datetime.now() + timedelta(hours=1)).isoformat()))
                db().commit()
                base = os.environ.get("SITE_URL") or request.host_url.rstrip("/")
                enviar(c["email"], None, "Recuperação de senha - GOLD VARIEDADES",
                       f"Olá, {c['nome']}!\n\nPara criar uma nova senha, abra o link (vale por 1 hora):\n{base}{url_for('redefinir_senha', token=token)}\n\nSe você não pediu, ignore esta mensagem.")
        flash("Se este e-mail estiver cadastrado, enviamos um link para redefinir a senha. Confira também a caixa de spam."
              + (" (Modo de teste: o link aparece no terminal do VS Code.)" if MODO_TESTE else ""), "ok")
        return redirect(url_for("esqueci_senha"))
    return render_template("esqueci.html")

@app.route("/redefinir-senha/<token>", methods=["GET", "POST"])
def redefinir_senha(token):
    r = db().execute("SELECT * FROM recuperacoes WHERE token_hash=? AND exp>?",
                     (hashlib.sha256(token.encode()).hexdigest(), datetime.now().isoformat())).fetchone()
    if not r:
        flash("Este link é inválido ou expirou. Peça um novo.", "erro")
        return redirect(url_for("esqueci_senha"))
    if request.method == "POST":
        s1, s2 = request.form.get("senha", ""), request.form.get("senha2", "")
        if len(s1) < 6: flash("A senha precisa de pelo menos 6 caracteres.", "erro")
        elif s1 != s2: flash("As senhas não são iguais.", "erro")
        else:
            db().execute("UPDATE clientes SET senha_hash=? WHERE id=?", (generate_password_hash(s1), r["cliente_id"]))
            db().execute("DELETE FROM recuperacoes WHERE cliente_id=?", (r["cliente_id"],)); db().commit()
            c = db().execute("SELECT * FROM clientes WHERE id=?", (r["cliente_id"],)).fetchone()
            enviar(c["email"], None, "Sua senha foi alterada", f"Olá, {c['nome']}! A senha da sua conta GOLD VARIEDADES foi alterada. Se não foi você, peça uma nova recuperação agora.")
            flash("Senha alterada! Entre com a nova senha.", "ok")
            return redirect(url_for("login_cliente"))
        return render_template("redefinir.html", token=token), 400
    return render_template("redefinir.html", token=token)

# ---------- minha conta (cliente) ----------
def cliente_required(f):
    @wraps(f)
    def w(*a, **k):
        if not session.get("cliente"):
            flash("Entre na sua conta para continuar.", "erro")
            return redirect(url_for("login_cliente"))
        return f(*a, **k)
    return w

def enderecos_salvos():
    if not session.get("cliente"): return []
    return db().execute("SELECT * FROM enderecos WHERE cliente_id=? ORDER BY padrao DESC, id", (session["cliente"],)).fetchall()

def pagina_conta(aba, **extra):
    cid = session["cliente"]
    c = db().execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()
    return render_template("conta.html", aba=aba, c=c, nomes=dict(ETAPAS), **extra)

@app.route("/minha-conta")
@cliente_required
def minha_conta():
    cid = session["cliente"]; n = lambda sql: db().execute(sql, (cid,)).fetchone()[0]
    return pagina_conta("resumo", recentes=pedidos_do(cid)[:3], n_ped=n("SELECT COUNT(*) FROM pedidos WHERE cliente_id=?"),
        n_and=n("SELECT COUNT(*) FROM pedidos WHERE cliente_id=? AND status!='entregue'"),
        n_fav=n("SELECT COUNT(*) FROM favoritos WHERE cliente_id=?"), n_end=n("SELECT COUNT(*) FROM enderecos WHERE cliente_id=?"))

@app.route("/minha-conta/dados", methods=["GET", "POST"])
@cliente_required
def conta_dados():
    if request.method == "POST":
        f, cid = request.form, session["cliente"]
        c = db().execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()
        if f.get("acao") == "perfil":
            nome, zap = f.get("nome", "").strip(), re.sub(r"\D", "", f.get("whatsapp", ""))
            if len(nome) < 3: flash("Informe seu nome (mínimo 3 letras).", "erro")
            elif zap and not 10 <= len(zap) <= 13: flash("WhatsApp inválido. Use DDD + número.", "erro")
            else:
                db().execute("UPDATE clientes SET nome=?, whatsapp=? WHERE id=?", (nome, zap, cid)); db().commit()
                flash("Dados atualizados!", "ok")
        else:
            nova = f.get("nova", "")
            if not check_password_hash(c["senha_hash"], f.get("atual", "")): flash("A senha atual está incorreta.", "erro")
            elif len(nova) < 6: flash("A nova senha precisa de pelo menos 6 caracteres.", "erro")
            elif nova != f.get("nova2"): flash("As senhas novas não são iguais.", "erro")
            else:
                db().execute("UPDATE clientes SET senha_hash=? WHERE id=?", (generate_password_hash(nova), cid)); db().commit()
                enviar(c["email"], None, "Sua senha foi alterada", f"Olá, {c['nome']}! A senha da sua conta GOLD VARIEDADES foi alterada.")
                flash("Senha alterada com sucesso!", "ok")
        return redirect(url_for("conta_dados"))
    return pagina_conta("dados")

@app.route("/minha-conta/enderecos", methods=["GET", "POST"])
@cliente_required
def conta_enderecos():
    cid = session["cliente"]
    if request.method == "POST":
        f = request.form; e = {k: f.get(k, "").strip() for k in ("apelido", "cep", "rua", "numero", "bairro", "cidade", "uf")}
        if not re.match(r"^\d{5}-?\d{3}$", e["cep"]) or not all(e[k] for k in ("rua", "numero", "bairro", "cidade")) or len(e["uf"]) != 2:
            flash("Confira o endereço: CEP (00000-000), rua, número, bairro, cidade e estado com 2 letras.", "erro")
        elif len(enderecos_salvos()) >= 5:
            flash("Você já tem 5 endereços salvos. Exclua um para adicionar outro.", "erro")
        else:
            primeiro = not enderecos_salvos()
            db().execute("INSERT INTO enderecos(cliente_id,apelido,cep,rua,numero,bairro,cidade,uf,padrao) VALUES(?,?,?,?,?,?,?,?,?)",
                (cid, e["apelido"] or "Casa", e["cep"], e["rua"], e["numero"], e["bairro"], e["cidade"], e["uf"].upper(), int(primeiro))); db().commit()
            flash("Endereço salvo!", "ok")
        return redirect(url_for("conta_enderecos"))
    return pagina_conta("enderecos", ends=enderecos_salvos())

@app.route("/minha-conta/enderecos/<int:eid>/<acao>", methods=["POST"])
@cliente_required
def conta_endereco_acao(eid, acao):
    cid = session["cliente"]
    if not db().execute("SELECT 1 FROM enderecos WHERE id=? AND cliente_id=?", (eid, cid)).fetchone(): abort(404)
    if acao == "excluir":
        db().execute("DELETE FROM enderecos WHERE id=?", (eid,))
        restante = db().execute("SELECT id FROM enderecos WHERE cliente_id=? AND padrao=1", (cid,)).fetchone()
        if not restante:
            db().execute("UPDATE enderecos SET padrao=1 WHERE id=(SELECT MIN(id) FROM enderecos WHERE cliente_id=?)", (cid,))
        flash("Endereço excluído.", "ok")
    elif acao == "padrao":
        db().execute("UPDATE enderecos SET padrao=(id=?) WHERE cliente_id=?", (eid, cid)); flash("Endereço padrão atualizado.", "ok")
    else: abort(400)
    db().commit()
    return redirect(url_for("conta_enderecos"))

@app.route("/carrinho/usar-endereco/<int:eid>", methods=["POST"])
@cliente_required
def usar_endereco(eid):
    e = db().execute("SELECT * FROM enderecos WHERE id=? AND cliente_id=?", (eid, session["cliente"])).fetchone()
    if not e: abort(404)
    session["end"] = {k: e[k] for k in ("cep", "rua", "numero", "bairro", "cidade", "uf")}
    session["frete"] = calcular_frete(e["cep"])
    flash("Endereço aplicado e frete calculado.", "ok")
    return redirect(url_for("carrinho"))

@app.route("/favorito/<int:pid>", methods=["POST"])
def favoritar(pid):
    if not session.get("cliente"):
        flash("Entre na sua conta para salvar favoritos.", "erro")
        return redirect(url_for("login_cliente"))
    if not db().execute("SELECT 1 FROM produtos WHERE id=?", (pid,)).fetchone(): abort(404)
    cid = session["cliente"]
    if db().execute("DELETE FROM favoritos WHERE cliente_id=? AND produto_id=?", (cid, pid)).rowcount == 0:
        db().execute("INSERT INTO favoritos(cliente_id,produto_id) VALUES(?,?)", (cid, pid)); flash("Adicionado aos favoritos.", "ok")
    else: flash("Removido dos favoritos.", "ok")
    db().commit()
    ref = request.referrer or ""
    return redirect(ref if ref.startswith(request.host_url) else url_for("home"))

@app.route("/minha-conta/favoritos")
@cliente_required
def conta_favoritos():
    fav = db().execute("""SELECT p.*, c.nome cat_nome, c.slug cat_slug FROM favoritos f JOIN produtos p ON p.id=f.produto_id
        JOIN categorias c ON c.id=p.categoria_id WHERE f.cliente_id=? AND p.status='aprovado' ORDER BY f.rowid DESC""", (session["cliente"],)).fetchall()
    return pagina_conta("favoritos", fav=fav)

# ---------- avaliações (nota de 0 a 10, com foto) e pagamento ----------
@app.route("/produto/<int:pid>/avaliar", methods=["POST"])
@cliente_required
def avaliar(pid):
    if not db().execute("SELECT 1 FROM produtos WHERE id=? AND status='aprovado'", (pid,)).fetchone(): abort(404)
    f, volta = request.form, url_for("produto", pid=pid) + "#avaliacoes"
    try: nota = int(f.get("nota", ""))
    except ValueError: nota = -1
    txt, arq, foto, erros = f.get("comentario", "").strip()[:800], request.files.get("foto"), None, []
    if not 0 <= nota <= 10: erros.append("Escolha uma nota de 0 a 10.")
    if len(txt) < 10: erros.append("Escreva um comentário com pelo menos 10 caracteres.")
    if arq and arq.filename:
        ext = arq.filename.rsplit(".", 1)[-1].lower()
        if ext in EXT: foto = f"uploads/aval_{uuid.uuid4().hex}.{ext}"
        else: erros.append("Foto inválida: use PNG, JPG, WEBP ou GIF.")
    if erros:
        for m in erros: flash(m, "erro")
        return redirect(volta)
    if foto: arq.save(os.path.join(BASE, "static", foto))
    db().execute("""INSERT INTO avaliacoes(produto_id,cliente_id,nota,comentario,foto,criado_em) VALUES(?,?,?,?,?,?)
        ON CONFLICT(produto_id,cliente_id) DO UPDATE SET nota=excluded.nota, comentario=excluded.comentario,
        foto=COALESCE(excluded.foto, foto), criado_em=excluded.criado_em""", (pid, session["cliente"], nota, txt, foto, datetime.now().isoformat()))
    db().commit()
    flash("Avaliação publicada! Obrigado.", "ok")
    return redirect(volta)

@app.route("/admin/avaliacao/<int:aid>/excluir", methods=["POST"])
@login_required
def excluir_avaliacao(aid):
    r = db().execute("SELECT produto_id FROM avaliacoes WHERE id=?", (aid,)).fetchone()
    if not r: abort(404)
    db().execute("DELETE FROM avaliacoes WHERE id=?", (aid,)); db().commit()
    flash("Avaliação excluída.", "ok")
    return redirect(url_for("produto", pid=r["produto_id"]) + "#avaliacoes")

@app.route("/admin/pedido/<int:pid>/pago", methods=["POST"])
@login_required
def admin_pago(pid):
    db().execute("UPDATE pedidos SET pago=1-COALESCE(pago,0) WHERE id=?", (pid,)); db().commit()
    flash("Pagamento atualizado.", "ok")
    return redirect(url_for("admin_pedidos"))

init_db()
if __name__ == "__main__":
    testar_smtp()
    host = os.environ.get("HOST", "127.0.0.1")
    # o modo debug só fica ligado quando o site é acessível apenas neste computador
    app.run(host=host, port=5000, debug=(host == "127.0.0.1"))
