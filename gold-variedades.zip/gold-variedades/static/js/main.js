const topo = document.querySelector('.topo');
const alternarMenu = forcar => {
  const aberto = topo.classList.toggle('menu-aberto', forcar);
  document.body.classList.toggle('sem-rolagem', aberto);
  document.querySelector('.burger').setAttribute('aria-expanded', aberto);
};
document.querySelectorAll('[data-menu]').forEach(b => b.addEventListener('click', () => alternarMenu()));
document.addEventListener('keydown', e => { if (e.key === 'Escape') alternarMenu(false); });
document.querySelectorAll('form[data-confirma]').forEach(f =>
  f.addEventListener('submit', e => { if (!confirm(f.dataset.confirma)) e.preventDefault(); }));
const num = v => parseFloat((v || '').replace('R$', '').trim().replace(/\./g, '').replace(',', '.')) || 0;
const po = document.querySelector('[data-po]'), pp = document.querySelector('[data-pp]'), d = document.querySelector('[data-desc]');
function desconto() {
  const a = num(po.value), b = num(pp.value);
  d.textContent = (a && b && b < a ? Math.round((1 - b / a) * 100) : 0) + '%';
}
if (po && pp && d) { po.addEventListener('input', desconto); pp.addEventListener('input', desconto); desconto(); }
document.querySelectorAll('.aviso.ok').forEach(a => setTimeout(() => a.remove(), 5000));

document.querySelectorAll('[data-copiar]').forEach(b => b.addEventListener('click', () => {
  const t = b.dataset.copiar, ok = () => { b.textContent = 'Link copiado!'; };
  if (navigator.clipboard) navigator.clipboard.writeText(t).then(ok, () => prompt('Copie o link:', t));
  else prompt('Copie o link:', t);
}));
const dlg = document.getElementById('dlg');
document.querySelectorAll('[data-prosseguir]').forEach(b => b.addEventListener('click', () => {
  const erro = document.getElementById('pg-erro'), falha = t => { if (erro) erro.textContent = t; };
  const r = document.querySelector('input[name=pagamento]:checked');
  if (!r) return falha('Escolha a forma de pagamento.');
  if (r.value !== 'pix') {
    const n = soDigitos(document.getElementById('c-num').value), cv = document.getElementById('c-cvv').value, band = bandeiraDe(n), tam = band === 'Amex' ? 4 : 3;
    if (!luhn(n)) return falha('Número do cartão inválido.');
    if (document.getElementById('c-nome').value.trim().length < 3) return falha('Informe o nome como está no cartão.');
    if (!validadeOk(document.getElementById('c-val').value)) return falha('Validade inválida ou vencida (use MM/AA).');
    if (cv.length !== tam) return falha('CVV inválido: são ' + tam + ' dígitos.');
    document.getElementById('h-final').value = n.slice(-4); document.getElementById('h-band').value = band;
  }
  falha(''); dlg && dlg.showModal();
}));
document.querySelectorAll('[data-fechar]').forEach(b => b.addEventListener('click', () => dlg.close()));
const TEMAS = {
  'Como comprar': ['Escolha um produto e clique em "Adicionar ao carrinho".', 'Abra o Carrinho e confira os itens e as quantidades.', 'Preencha o endereço e clique em "Calcular frete e prazo".', 'Clique em "Prosseguir" e confirme com "Sim".', 'Pronto! Acompanhe tudo em "Meus pedidos".'],
  'Criar conta': ['Clique em "Cadastrar" no topo da página.', 'Preencha seus dados e escolha receber o código por e-mail ou WhatsApp.', 'Digite os 4 dígitos recebidos. Sem o código, o cadastro não é concluído.', 'Se o código não chegar, use "Reenviar código".'],
  'Frete e prazo': ['O frete é calculado pela distância entre a loja e o seu CEP.', 'O prazo aumenta conforme a distância.', 'Você vê o valor e os dias antes de confirmar o pedido.'],
  'Rastrear pedido': ['Entre em "Meus pedidos".', 'Cada pedido mostra as etapas: recebido, retirado, a caminho e entregue.'],
  'Seja afiliado': ['Influenciadores e marcas criam uma conta em "Seja afiliado".', 'Cadastram produtos com o seu link e ganham uma vitrine para divulgar.', 'Cada produto passa por aprovação antes de aparecer.'],
  'Minha loja': ['Crie sua conta e abra "Minha loja".', 'Cadastre seus produtos próprios com foto, preço e link de compra.', 'Divulgue o link da sua loja.'],
  'Ajuda e reclamações': ['Para falar com um vendedor, use "Falar com o vendedor" na página do produto ou da loja.', 'Para registrar um problema, use o "Reclame Aqui" no menu.']
};
const chat = document.getElementById('chat'), corpo = document.getElementById('chat-corpo'), ops = document.getElementById('chat-op');
const fala = (t, eu) => { const p = document.createElement('p'); if (eu) p.className = 'eu'; p.textContent = t; corpo.appendChild(p); corpo.scrollTop = corpo.scrollHeight; };
if (chat) {
  Object.keys(TEMAS).forEach(k => { const b = document.createElement('button'); b.textContent = k; b.onclick = () => {
    fala(k, true); TEMAS[k].forEach((t, i) => setTimeout(() => fala((i + 1) + '. ' + t), 450 * (i + 1))); }; ops.appendChild(b); });
  document.querySelectorAll('[data-chat]').forEach(b => b.addEventListener('click', () => {
    chat.hidden = !chat.hidden; if (!chat.hidden && !corpo.children.length) fala('Olá! Sobre o que você quer saber?'); }));
}

document.querySelectorAll('input[name=cep]').forEach(inp => {
  const f = inp.form, aviso = f && f.querySelector('[data-cep-aviso]');
  const msg = t => { if (aviso) aviso.textContent = t; };
  const buscar = async () => {
    const cep = inp.value.replace(/\D/g, ''); if (cep.length !== 8) return;
    msg('Buscando endereço...');
    try {
      const d = await (await fetch('https://viacep.com.br/ws/' + cep + '/json/')).json();
      if (d.erro) return msg('CEP não encontrado. Preencha o endereço manualmente.');
      [['rua', d.logradouro], ['bairro', d.bairro], ['cidade', d.localidade], ['uf', d.uf]].forEach(([n, v]) => { if (f.elements[n] && v) f.elements[n].value = v; });
      msg('Endereço encontrado. Confira e informe o número.'); if (f.elements.numero) f.elements.numero.focus();
    } catch (e) { msg('Não foi possível buscar o CEP agora. Preencha manualmente.'); }
  };
  inp.addEventListener('input', () => { const d = inp.value.replace(/\D/g, '').slice(0, 8); inp.value = d.length > 5 ? d.slice(0, 5) + '-' + d.slice(5) : d; if (d.length === 8) buscar(); });
  inp.addEventListener('blur', buscar);
});

// CARTAO-FUNCOES
const soDigitos = v => v.replace(/\D/g, '');
const luhn = n => { let s = 0, alt = false; for (let i = n.length - 1; i >= 0; i--) { let d = +n[i]; if (alt) { d *= 2; if (d > 9) d -= 9; } s += d; alt = !alt; } return n.length >= 13 && s % 10 === 0; };
const bandeiraDe = n => /^(606282|3841)/.test(n) ? 'Hipercard' : /^(4011|4312|4389|4514|4576|5041|5066|5067|509|6277|6362|6363|6500|6504|6505|6516)/.test(n) ? 'Elo' : /^4/.test(n) ? 'Visa' : /^(5[1-5]|222[1-9]|22[3-9]\d|2[3-6]\d\d|27[01]\d|2720)/.test(n) ? 'Mastercard' : /^3[47]/.test(n) ? 'Amex' : 'Cartão';
const validadeOk = v => { const [m, a] = v.split('/'); if (!/^\d{2}$/.test(m || '') || !/^\d{2}$/.test(a || '')) return false; const mes = +m, ano = 2000 + +a, h = new Date(); return mes >= 1 && mes <= 12 && (ano > h.getFullYear() || (ano === h.getFullYear() && mes >= h.getMonth() + 1)); };
// FIM-CARTAO-FUNCOES
const cartaoBox = document.getElementById('cartao-box');
if (cartaoBox) {
  const parc = document.getElementById('parcelas-box'), sel = parc.querySelector('select');
  const num = document.getElementById('c-num'), val = document.getElementById('c-val'), cvv = document.getElementById('c-cvv'), band = document.getElementById('c-band');
  const atualizar = () => { const r = document.querySelector('input[name=pagamento]:checked'), p = r ? r.value : '';
    cartaoBox.hidden = !(p === 'debito' || p === 'credito'); parc.hidden = p !== 'credito'; if (sel) sel.disabled = p !== 'credito'; };
  document.querySelectorAll('input[name=pagamento]').forEach(r => r.addEventListener('change', atualizar)); atualizar();
  num.addEventListener('input', () => { const d = soDigitos(num.value).slice(0, 19); num.value = d.replace(/(.{4})/g, '$1 ').trim(); band.textContent = d.length >= 4 ? bandeiraDe(d) : ''; });
  val.addEventListener('input', () => { const d = soDigitos(val.value).slice(0, 4); val.value = d.length > 2 ? d.slice(0, 2) + '/' + d.slice(2) : d; });
  cvv.addEventListener('input', () => { cvv.value = soDigitos(cvv.value).slice(0, 4); });
}

document.querySelectorAll('[data-contagem]').forEach(el => {
  let s = +el.dataset.contagem; const p = n => String(n).padStart(2, '0');
  const t = () => { el.textContent = p(Math.floor(s / 3600)) + ':' + p(Math.floor(s % 3600 / 60)) + ':' + p(s % 60); if (s > 0) s--; else location.reload(); };
  t(); setInterval(t, 1000);
});
