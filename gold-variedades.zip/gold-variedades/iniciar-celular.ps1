﻿# Liga o site para o celular, com envio de e-mail pelo Gmail.
# Como usar: no terminal do VS Code, dentro desta pasta, digite:  .\iniciar-celular.ps1
Set-Location $PSScriptRoot
$email = "carolchaves2007@gmail.com"   # troque aqui se usar outro Gmail

$ip = (Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -and $_.NetAdapter.Status -eq "Up" } | Select-Object -First 1).IPv4Address.IPAddress
if (-not $ip) { $ip = Read-Host "Nao achei o IP automaticamente. Digite o IPv4 do computador (ipconfig)" }

$segura = Read-Host "Cole a SENHA DE APP do Gmail (16 letras). Ela nao aparece na tela" -AsSecureString
$senha = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($segura))
$env:SMTP_PASS = $senha.Replace(" ", "")

$env:HOST = "0.0.0.0"
$env:SITE_URL = "http://${ip}:5000"
$env:SMTP_HOST = "smtp.gmail.com"
$env:SMTP_PORT = "587"
$env:SMTP_USER = $email

Write-Host ""
Write-Host "No celular (mesmo Wi-Fi), abra: http://${ip}:5000" -ForegroundColor Yellow
Write-Host ""
$py = Join-Path $PSScriptRoot "..\venv\Scripts\python.exe"
if (-not (Test-Path $py)) { $py = "python" }
& $py app.py
